# وارد کردن کتابخونه‌های مورد نیاز
import json  # برای کار با فایل‌های JSON
import logging  # برای ثبت وقایع
from flask import Flask, request, jsonify  # برای ساخت وب سرور
import numpy as np  # برای کار با آرایه‌ها و محاسبات ریاضی
import tensorflow as tf  # برای کار با مدل یادگیری ماشین
from sklearn.preprocessing import MinMaxScaler  # برای نرمال‌سازی داده‌ها
import time  # برای اندازه‌گیری زمان
import os  # برای کار با سیستم عامل
from datetime import datetime  # برای کار با تاریخ و زمان
from functools import wraps  # برای ساخت دکوراتور

# تنظیمات لاگینگ
logging.basicConfig(filename='app.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

# ساخت یک نمونه از Flask
app = Flask(__name__)

# تنظیمات اپلیکیشن
app.config['MODEL_PATH'] = "my_model2.h5"  # مسیر فایل مدل
app.config['DATA_FILE'] = 'parkinsons_data.json'  # اسم فایل ذخیره داده‌ها
app.config['MAX_SENSOR_DATA'] = 120  # حداکثر تعداد داده‌های سنسور

# لود کردن مدل
try:
    model = tf.keras.models.load_model(app.config['MODEL_PATH'])
    logging.info("مدل با موفقیت بارگذاری شد")
except Exception as e:
    logging.error(f"خطا در بارگذاری مدل: {str(e)}")
    raise

# ایجاد یک نمونه از MinMaxScaler برای نرمال‌سازی داده‌ها
scaler = MinMaxScaler()

def error_handler(func):
    """یک دکوراتور برای مدیریت خطاها"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            logging.error(f"خطا در {func.__name__}: {str(e)}")
            return jsonify({'error': 'یک خطای داخلی رخ داد'}), 500
    return wrapper

def validate_input(data):
    """اعتبارسنجی داده‌های ورودی"""
    if 'sensor_data' not in data or 'gender' not in data or 'age' not in data:
        raise ValueError("داده‌های ورودی ناقص هستند")
    if not isinstance(data['sensor_data'], list) or len(data['sensor_data']) == 0:
        raise ValueError("داده‌های سنسور نامعتبر هستند")
    if data['gender'] not in ['Male', 'Female']:
        raise ValueError("جنسیت نامعتبر است")
    if not isinstance(data['age'], int) or data['age'] <= 0:
        raise ValueError("سن نامعتبر است")

def preprocess_sensor_data(sensor_data):
    """پیش‌پردازش داده‌های سنسور"""
    # تبدیل داده‌های سنسور به آرایه numpy
    sensor_array = np.array([
        [item['sensorX'], item['sensorY'], item['sensorZ']] for item in sensor_data
    ])
    
    # اطمینان از اینکه شکل داده‌ها درست است
    if sensor_array.shape[0] < app.config['MAX_SENSOR_DATA']:
        # اگر داده‌ها کمتر از حداکثر مقدار باشند، با صفر پر می‌شوند
        padding = np.zeros((app.config['MAX_SENSOR_DATA'] - sensor_array.shape[0], 3))
        sensor_array = np.vstack((sensor_array, padding))
    elif sensor_array.shape[0] > app.config['MAX_SENSOR_DATA']:
        # اگر داده‌ها بیشتر از حداکثر مقدار باشند، فقط MAX_SENSOR_DATA اول را نگه می‌داریم
        sensor_array = sensor_array[:app.config['MAX_SENSOR_DATA'], :]
    
    # نرمال‌سازی داده‌ها
    sensor_array = scaler.fit_transform(sensor_array)
    
    return sensor_array.reshape(1, app.config['MAX_SENSOR_DATA'], 3)

def save_to_json(data):
    """ذخیره داده‌ها در فایل JSON"""
    filename = app.config['DATA_FILE']
    if os.path.exists(filename):
        with open(filename, 'r') as f:
            existing_data = json.load(f)
    else:
        existing_data = []
    
    existing_data.append(data)
    
    with open(filename, 'w') as f:
        json.dump(existing_data, f, indent=4)
    
    logging.info(f"داده‌ها در {filename} ذخیره شدند")

def get_prediction_result(probability):
    """تعیین نتیجه بر اساس احتمال پیش‌بینی شده"""
    if probability < 0.4:
        return "پارکینسون تشخیص داده نشد"
    elif probability > 0.6:
        return "پارکینسون تشخیص داده شد"
    else:
        return "نیاز به بررسی بیشتر"

@app.route('/health', methods=['GET'])
def health_check():
    """بررسی سلامت سرور"""
    return jsonify({'status': 'ok', 'timestamp': datetime.now().isoformat()})

@app.route('/predict', methods=['POST'])
@error_handler
def predict():
    """انجام پیش‌بینی بر اساس داده‌های ورودی"""
    start_time = time.time()
    
    # دریافت داده‌های ورودی
    data = request.json
    logging.info(f"داده‌های دریافتی: {data}")
    
    # اعتبارسنجی داده‌های ورودی
    validate_input(data)
    
    # پیش‌پردازش داده‌های سنسور
    sensor_data = preprocess_sensor_data(data['sensor_data'])
    
    # آماده‌سازی داده‌های ورودی برای مدل
    gender = 1 if data['gender'] == 'Male' else 0
    age = data['age']
    
    # انجام پیش‌بینی
    prediction = model.predict([sensor_data, np.array([[gender]]), np.array([[age]])])
    probability = float(prediction[0][0])
    
    # تعیین نتیجه
    result = get_prediction_result(probability)
    
    # محاسبه زمان پردازش
    process_time = time.time() - start_time
    
    # آماده‌سازی داده‌های پاسخ
    response_data = {
        'result': result,
        'probability': probability,
        'process_time': f"{process_time:.2f} seconds"
    }
    
    # ذخیره داده‌ها
    save_data = {
        'sensor_data': data['sensor_data'],
        'gender': data['gender'],
        'age': age,
        'prediction': response_data,
        'timestamp': datetime.now().isoformat()
    }
    save_to_json(save_data)
    
    logging.info(f"نتیجه پیش‌بینی: {result}")
    
    # ارسال پاسخ
    return jsonify({'result': result})

@app.errorhandler(404)
def not_found(error):
    """مدیریت خطای 404"""
    return jsonify({'error': 'صفحه مورد نظر یافت نشد'}), 404

@app.errorhandler(405)
def method_not_allowed(error):
    """مدیریت خطای 405"""
    return jsonify({'error': 'روش درخواست مجاز نیست'}), 405

if __name__ == '__main__':
    # تنظیمات اجرای سرور
    host = os.environ.get('FLASK_HOST', '0.0.0.0')
    port = int(os.environ.get('FLASK_PORT', 1200))
    debug = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    
    logging.info(f"شروع سرور بر روی {host}:{port}")
    app.run(host=host, port=port, debug=debug)
